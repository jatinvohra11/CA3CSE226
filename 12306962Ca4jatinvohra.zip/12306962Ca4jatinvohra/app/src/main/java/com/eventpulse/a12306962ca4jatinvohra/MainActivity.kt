package com.eventpulse.a12306962ca4jatinvohra

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import com.eventpulse.a12306962ca4jatinvohra.ui.theme._12306962Ca4jatinvohraTheme

data class Movie(
    val title: String,
    val genre: String
)

class MovieRepository {

    private val movieList = mutableListOf<Movie>()

    private val _movies = MutableStateFlow<List<Movie>>(emptyList())
    val movies: StateFlow<List<Movie>> = _movies.asStateFlow()

    private val _movieCount = MutableStateFlow(0)
    val movieCount: StateFlow<Int> = _movieCount.asStateFlow()

    fun addMovie(movie: Movie) {
        movieList.add(movie)
        _movies.value = movieList.toList()
        _movieCount.value = movieList.size
    }
}

class MovieViewModel : ViewModel() {

    private val repository = MovieRepository()

    val movies = repository.movies
    val movieCount = repository.movieCount

    fun addMovie(title: String, genre: String) {
        if (title.isNotBlank() && genre.isNotBlank()) {
            repository.addMovie(Movie(title, genre))
        }
    }
}

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val movieViewModel =
            ViewModelProvider(this)[MovieViewModel::class.java]

        setContent {
            _12306962Ca4jatinvohraTheme {
                MovieScreen(movieViewModel)
            }
        }
    }
}

@Composable
fun MovieScreen(viewModel: MovieViewModel) {

    var title by remember { mutableStateOf("") }
    var genre by remember { mutableStateOf("") }

    val movies by viewModel.movies.collectAsState()
    val count by viewModel.movieCount.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize()
    ) { padding ->

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Text(
                text = "Movie Watchlist",
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(modifier = Modifier.height(16.dp))
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Movie Title") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = genre,
                onValueChange = { genre = it },
                label = { Text("Movie Genre") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = {
                    viewModel.addMovie(title, genre)
                    title = ""
                    genre = ""
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Add Movie")
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Total Movies: $count",
                style = MaterialTheme.typography.titleLarge
            )

            Spacer(modifier = Modifier.height(8.dp))

            LazyColumn {
                items(movies) { movie ->

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Text(
                                text = movie.title,
                                style = MaterialTheme.typography.titleMedium
                            )

                            Text(text = "Genre: ${movie.genre}")
                        }
                    }
                }
            }
        }
    }
}